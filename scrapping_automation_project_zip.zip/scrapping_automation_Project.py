# Step 0: Install all the requirements
# pip install requests
# pip install bs4
# pip install html5lib

import requests
import json
from bs4 import BeautifulSoup
url = "https://www.midsouthshooterssupply.com/dept/reloading/primers?currentpage=1"

# Step 1: Get the HTML
r = requests.get(url)
python_data=json.loads(response,text)
htmlContent = r.content

# Step 2: Parse the HTML
soup = BeautifulSoup(htmlContent, 'html.parser')

# Step 3: HTML Tree traversal

# # 4. Comment
# markup = "<p><!-- this is a comment --></p>"
# soup2 = BeautifulSoup(markup)
# print(type(soup2.p.string))


# a) Get the title of the HTML page
title = soup.title

# b) Get all the prices in Dollar
paras = soup.find_all('p')

# c) stock status (stock-in or stock-out)
stock = soup.find_all('a')
for item in stock:
    if stock==True:
        print("in_stock")
    else:
        print("out_stock")


# Get all the links on the page:
#Manufacturer
for link in stock:
    if(link.get('href') != '#'): 
        linkText = "https://www.midsouthshooterssupply.com/b/remington" +link.get('href')
        all_links.add(link)
        # print(linkText)

navbarSupportedContent = soup.find(id='navbarSupportedContent')

# .contents - A tag's children are available as a list
# .children - A tag's children are available as a generator
# for elem in navbarSupportedContent.contents:
#     print(elem)
 
# for item in navbarSupportedContent.strings:
#     print(item)

# for item in navbarSupportedContent.stripped_strings:
#     print(item)

# print(navbarSupportedContent.parent)
# for item in navbarSupportedContent.parents: 
#     print(item.name)

# print(navbarSupportedContent.next_sibling.next_sibling)
# print(navbarSupportedContent.previous_sibling.previous_sibling)

# elem = soup.select('.modal-footer')
# print(elem)
elem = soup.select('#loginModal')[0] 
print(elem)

#made by IBAD SIDDIQUI
